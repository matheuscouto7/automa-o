/// <reference types="cypress" />
import { loginPage } from '../../../util.js';

it('Deve fazer o login', () =>{
    loginPage()

})
